# OpenSourceArmenia
It will create an open-minded society.
Yes.
